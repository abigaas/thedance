const gameState = {
  beloChecked: 0,
  beloLoop: 0,
  injuChecked: 0,
  wentHome: 0,
  hasLooped: 0,
  skullDialogue: 0,
  witchTalked: 0,
  witchWent: 0,
  // Inventory
  hasVial: 0,
  hasBook: 0,
  hasGem: 0,
};

const story = {
  start: {
    setVars: { injuChecked: 0, beloChecked: 0, wentHome: 0, hasBook: 0, beloLoop: 0, hasVial: 0, hasBook: 0, skullDialogue: 0, witchTalked: 0, witchWent: 0 },
    title: "Waking Up",
    text: "The first thing that hits you is the smell: old unwashed clothes, booze, cigarettes and blood. As your eyes open again you can see the cold, grey ground, an apparently endless field of concrete that fills your field of vision. As you somehow manage to move your body so you can lay on your back, you can see the tall buildings surrounding you, piercing the black sky, as a faint rain hits your face. Everything hurts.",
    choices: [
      { text: "Get up", next: "everythinghurts" },
    ]
  },
  
  everythinghurts: {
    title: "Everything hurts",
    text: "You are alone in this street corner. Getting up is one of the hardest things you've ever done, as every muscle in your body is screaming in pain. You look up, beyond the faint streelight above you, drops of rain scintillating in its glow, to the window of the apartment you were just in. Two stories drop. It's incredible that you didn't break any bone, even if the pain you're feeling would say otherwise. Looks like no one is coming for you at least, they probably think you are dead.",
    choices: function () {
      const list = [];
      
      if (gameState.injuChecked === 0) {
      list.push({ text: "Check your injuries", next: "checkinju" });
    }
    
        if (gameState.beloChecked === 0 && gameState.hasLooped === 0) {
      list.push({ text: "Check your belongings", next: "checkbelo" });
    }
    
            if (gameState.beloLoop === 0 && gameState.hasLooped === 1) {
      list.push({ text: "Check your belongings", next: "checkbeloloop" });
    }
      
          list.push({ text: "Look Around", next: "lookaround" });

    return list;
 
    }
  },
  
  lookaround: {
    title: "The Concrete Jungle",
    text: "Not a single soul around. The endless roads and tall buildings are reminding you there is no escape from here. However, you know that you can't stay here, someone could be coming for you.",
  choices: function () {
    const list = [];

    if (gameState.injuChecked === 0) {
      list.push({ text: "Check your injuries", next: "checkinju" });
    }
    
        if (gameState.beloChecked === 0 && gameState.hasLooped === 0) {
      list.push({ text: "Check your belongings", next: "checkbelo" });
    }
    
            if (gameState.beloLoop === 0 && gameState.hasLooped === 1) {
      list.push({ text: "Check your belongings", next: "checkbeloloop" });
    }

    list.push({ text: "Get out of here", next: "getout" });

    return list;
  }
},
  
  getout: {
    title: "Leaving the scene",
    text: "Every step you take feels like someone is stabbing you a thousand times. Your breath is heavy as you move as quick as you can along the roads. You wish you could just lay down and rest, but you know that would be the end for you. You have to keep going. Where to though? Should you go back to Kinglsey at Aphoria, hoping that he's going to be fine with the deal failed? Or maybe you should go back to the apartment and try again, hoping that your desperation might look convincing? Or maybe you should just go home and think about it tomorrow.",
    choices: [
      {text: "Keep moving", next: "road1"},
    ]
  },
  
  
  checkinju: {
       setVars: { injuChecked: 1 },
    title: "Your body",
    text: "You move your coat and lift your shirt. Most of your torso is covered in bruises and blood.",
 choices: function () {
    const list = [];

    if (gameState.beloChecked === 0 && gameState.hasLooped === 0) {
      list.push({ text: "Check your belongings", next: "checkbelo" });
    }
   
       if (gameState.beloLoop === 0 && gameState.hasLooped === 1) {
      list.push({ text: "Check your belongings", next: "checkbeloloop" });
    }

    list.push({ text: "Look around", next: "lookaround" });

    return list;
  }
},
  
checkbelo: {
  title: "Your belongings",
  text: "You put your hand into the pocket of your trousers, and a sharp pain hits you. As you take your phone out of it you realize why: it didn't survive the fall, the screen is completely shattered and shards of glass are now in your thumb. You try to turn it on, to no avail. You check the inside pocket of your coat, dreading the worst. A wave of relief fills your body as you can see the container is still intact. The Witch thought it was fake, and as a consequence you flew for a bit. But she has to be wrong, right? Kingsley would never do this to you. Right?. The liquid inside the small vial shimmers faintly behind the light of the street lamps.",
   setVars: { beloChecked: 1, hasVial: 1 },
  choices: function () {
    const list = [];

    if (gameState.injuChecked === 0) {
      list.push({ text: "Check your injuries", next: "checkinju" });
    }

    list.push({ text: "Look around", next: "lookaround" });

    return list;
  }
},
  
  checkbeloloop: {
  title: "Your belongings",
  text: "You put your hand into the pocket of your trousers, and a sharp pain hits you. As you take your phone out of it you realize why: it didn't survive the fall, the screen is completely shattered and shards of glass are now in your thumb. You try to turn it on, to no avail. You check the inside pocket of your coat, dreading the worst. A wave of fear fills your body as you can't feel the vial. Did the Witch take it before she threw you out? Did it landed somewhere else during the fall? You look around you but you can't see it anywhere.",
       setVars: { beloLoop: 1 },
  choices: function () {
    const list = [];

    if (gameState.injuChecked === 0) {
      list.push({ text: "Check your injuries", next: "checkinju" });
    }

    list.push({ text: "Look around", next: "lookaround" });

    return list;
  }
},
 
 
  road1: {
    title: "Now what?",
    text: "Where should you go now?",
    
     choices: function () {
    const list = [];

    if (gameState.wentHome === 0) {
      list.push({ text: "Go home", next: "home" });
    }
       
           if (gameState.wentHome === 1) {
      list.push({ text: "Go to your apartment", next: "yourapartment" });
    }

    list.push({ text: "Go to Aphoria", next: "aphoriaoutside" });
       
       if (gameState.witchWent === 1) {
    list.push({ text: "Go to the Witch apartment", next: "apartmentoutside" });
       }
       
              if (gameState.witchWent === 0) {
    list.push({ text: "Go back to the delivery", next: "backtobusiness" });
       }
       
       
    return list;
  }
  },
  
  home: {
    title: "Almost home",
    text: "You arrive at the door of your apartment building drenched in blood and rain. You step inside the dark entrance hall, its walls covered in mold and graffiti, as the buzzing of the only functioning neon light in one of the corners and the skittering of critters in the walls welcome you. You are afraid you are going to faint every second now and you hope that no one will see you in this state, but you decide to still take the elevator to avoid the pain that taking the stairs would inflict you. As the elevator doors open, you flinch for a second realising that someone is inside, but you feel reassured when you notice that it’s your neighbour, Ms Ladin, who can barely see, her eyes ruined by the weight of her years.",
    setVars: { wentHome: 1 },
    choices: [
      {text: "Stay silent", next: "ladinleaves"},
      {text: "Greet her", next: "ladinconvo"},
    ]
  },
  
  ladinconvo: {
    title: "Miss Ladin",
    text: '"Miss Ladin"’, you say out loud, the voice cracking under the pain coming from your lungs. She looks startled for a second, before she recognises the voice and her expression morphs into a warm smile, her white curly hair the brightest thing in the room. "Oh dear, what are you doing up so late?"',
    choices: [
      {text: '"Work"', next: "workanswer"},
      {text: '"I could ask you the same thing"', next: "samethinganswer"},
    ]
  },
  
  workanswer: {
    title: '"Work"',
    text: 'She lifts her hand and caresses gently your face as her blind eyes square up your silhouette. "You’re working too much, you should rest sometimes. I know it’s hard but you have to take care of yourself, do you promise?". You nod, knowing that she will understand the motion you’re making while her hand is on your face. If you truly believe it, that’s only for you to know. "Hold on", she says, "I found this in my house but I can’t really do much with it, I want you to have it". She takes a book out of her purse and offers it to you. It looks a bit ruined by the passage of time and there’s no title on it.',
    choices:[
            {text: "Accept the gift", next: "bookaccept"},
            {text: "Refuse the gift", next: "bookrefuse"},
    ]
  },
  
  bookaccept: {
    setVars: { hasBook: 1 },
    title: "Accept the gift",
    text: 'You take the book with you and thank her. She smiles again before leaving the building without saying another word.',
       choices:[
      {text: "Go to your apartment", next: "yourapartment"},
    ]
  },
  
  bookrefuse: {
    title: "Refuse the gift",
    text: '"I don’t really have time to read lately, Miss Ladin. You should probably give it to someone else". She looks visibly disappointed as she puts the book back in her purse, but after a second a smile appears on her face. She gently caresses your face before leaving the building without saying another word.',
    choices: [
      {text: "Go to your apartment", next: "yourapartment"},
    ]
  },
  
  samethinganswer: {
    title: '"I could ask you the same thing"',
    text: 'She laughs a bit as you finish asking the question. "You’re right my dear", she says while still chuckling, "but I can’t tell you my secrets. Just trust me that I’m going exactly where I want to go". You look at her and her frail small body, feeling for a second the instinct to protect her somehow, even if you probably wouldn’t be able to protect anything right now. She caresses gently your face before she leaves the building without saying another word.',
    choices: [
      {text: "Go to your apartment", next: "yourapartment"},
    ]
  },
  
  ladinleaves: {
    title: "As she leaves",
    text: "You move to the side to avoid her and don’t say a word. She gets off the elevator and walks outside. You are wondering where she is going at this hour. You spoke to her many times: she’s sweet and caring, always offering her ear in times of need. However sometimes you wake up because of the screams coming from her apartment, her yelling at some invisible threat, probably long gone and only living in the confusion of her ancient mind. You tried to check on her a couple of times, but when she opened the door, she was always calm and smiling.",
    choices: [
      {text: "Go to your apartment", next: "yourapartment"}
              ]
  },
  
  yourapartment: {
    title: "Your apartment",
    text: "You are so tired, what should you do? (to complete)",
    
    choices: function () {
    const list = [];

    if (gameState.beloChecked === 1) {
      list.push({ text: "Drink the vial", next: "thevial" });
    }
    if (gameState.hasBook === 1) {
      list.push({ text: "Read the book", next: "thebook" });
    }
    list.push({ text: "Go back outside", next: "road1" });
    list.push({ text: "Go to sleep", next: "sleepending" });
       
    return list;
  }
  },
  
  thevial: {
    setVars: { hasVial: 0},
    title: "The vial",
    text: "You drink the vial",
    choices: [
      {text: "Fall asleep", next: "thedream"}
    ]
  },
  
  thebook: {
    title: "The Book",
    text: 'Book text.',
    choices: [
      {text: "Put the book down", next: "yourapartment"},
    ]
  },
  
  sleepending: {
    setVars: { hasLooped: 0 },
    title: "Goodnight",
    text: "You go to sleep for the last time.",
    choices: [
      {text: "Ending: Goodnight", next: "start"},
    ]
  },
  
  thedream: {
    title: "The Dream",
    text: "You are flying in an endless sea of stars, the immensity of the universe twirling around you, enveloping you, protecting you. You feel at peace as the pain disappears and you feel like you are submerged in the secret of the cosmos. On your left a massive purple nebula, stars shimmering in its body, is slowly pulsating, like a heartbeat, inviting you to become one with it. But in this moment, your eyes are focused on the slow dance of the infinite stars.",
    choices: [
      {text: "Join the Dance", next: "thedance"},
      {text: "Approach the Nebula", next: "nebula"},
    ]
  },
  
   thedance: {
    setVars: { hasLooped: 1 },
    title: "The Dance",
    text: "You move your limbs slowly, following the rhythm of the cosmos, not even thinking about what you’re supposed to do: it’s almost a second nature to you. The stars move with you, following your lead, as you plunge deeper and deeper in the vast dark expanse. You close your eyes as a smile appears on your face, and for a moment you finally feel at peace. But, as quickly the peace comes, it disappears as you open your eyes again and can see the top of the streetlights and the ground quickly approaching.",
    choices: [
      {text: "The End?", next: "start"},
    ]
  },
  
    nebula: {
    title: "Nebula",
    text: 'You swear you can hear faint music coming from the massive celestial object in front of you, like a sweet old song playing from a gramophone, unsure if it’s coming from near you or from millions of light years afar. The stars trapped in its gaseous body flash at a steady pace, following the rhythm. A feminine voice starts singing a few words as the music picks up. "What is that you desire?" she sings.',
    choices: [
      {text: '"I want to stay"', next: "dreamend"},
      {text: "Leave and join the Dance", next: "thedance"},
    ]
  },
  
    dreamend: {
    setVars: { hasLooped: 0 },
    title: "Lullaby",
    text: "The nebula surrounds you, cradling you as the song of the cosmos continues playing until the end of time. You can finally rest.",
    choices: [
      {text: "Ending: Protection", next: "start"},
    ]
  },
  
  backtobusiness: {
    setVars: { witchWent: 1 },
    title: "Back to business",
    text: "You go back around the corner and enter the building through the door that you left open earlier. As you climb up the stairs you can't shake the feel that this could be a mistake. You already almost died here. Your only hope is that the Witch will somehow respect you for showing up again after she just tried to kill you. Maybe she can be convinced.",
    choices: [
      {text: "Go to the Witch apartment", next: "apartmentoutside"},
    ]
  },
  
  apartmentoutside: {
     title: "Outside the Witch apartment",
    text: " You arrive in front of the Witch apartment, a skull with glowing red eyes etched in the door greeting you again.",
    choices: function () {
    const list = [];

    if (gameState.skullDialogue === 0) {
      list.push({ text: "Knock on the door", next: "witchapknock" });
    }

    if (gameState.witchTalked === 0) {
    list.push({ text: "Kick the door and rush in", next: "witchapkick" });
    }
      
   list.push({ text: "Go back outside", next: "road1" });
    return list;
  }
  },
  
  witchapkick: {
     title: "Possibly a mistake",
    text: 'You gather all the energies you have left in your body to hit the door with your foot. The door burst open with ease, way too much ease, as the skull starts cackling. You lose your balance and fall on the ground inside the apartment. You can see hundreds of shadows moving irregularly around the room, as footsteps approach you. You raise your gaze too meet hers. The Witch looks at you, glowing eyes shining in the darkness of her shape. "I fail to understand your logic", she tells you, her words piercing your mind like needles.',
    choices: [
      {text: '"Please just listen to me"', next: "witchdialogue1"},
      {text: "Attack her", next: "witchkillending"},
    ]
  },
  
  witchapknock: {
    title: "A knock on the door",
    text: 'You knock a few times on the door. No response. After a few more seconds the glowing red eyes of the skull etched on the door move, staring directly into yours, as its jaw start moving in a mocking way. "You are not welcome here anymore", it says.',
    choices: [
    {text: '"I need to speak to her"', next: "skulldialogue"},
    {text: "Kick the door", next: "witchapkick"},
    {text: "Leave", next: "road1"}
    ]
  },
  
  skulldialogue: {
    setVars: { skullDialogue: 1 },
    title: '"I need to speak to her"',
    text: 'The skull burst in a deafening laughter. "You had your chance", it says. "Now it is time for you to deal with consequences of your actions". As it finishes speaking, it becomes inanimate again',
    choices: [
    {text: "Kick the door", next: "witchapkick"},
    {text: "Leave", next: "road1"},
              ]
  },
  
  witchdialogue1: {
    title: '"Please just listen to me"',
    text: 'Her everchanging form approaches you. "I always listen. I listened to the rivers, and the rocks, and the trees. I listened to the birds and the starts at the beginning of time. I heard the song of chaos and the melody of creation. Tell me, why do you think I did not listen to you? Is it your sin you want to wash away?"',
     choices: function () {
    const list = [];

    if (gameState.hasVial === 1) {
      list.push({ text: '"You are wrong about the Vial, it is the real thing."', next: "witchdialogue2" });
    }
       
    if (gameState.hasGem === 1) {
      list.push({ text: "Present the gem", next: "witchdialoguegem" });
    }
       
    list.push({ text: '"We started with the wrong foot, trust me"', next: "witchwrongfoot" });
   list.push({ text: "Attack her", next: "witchkillending" });
    return list;
  }
  },
  
  witchwrongfoot: {
    setVars: {witchTalked: 1},
    title: '"We started with the wrong foot"',
    text: 'The Witch hovers over you, the light distorting as it touches her form, making impossible to understand how tall or distant she actually is. "And with it we will be done", she says, as your body gets thrown out of the door, which shuts close by itself. The skull laughs at you one last time',
    choices: [
      {text: "Leave", next: "road1"},
    ]
  },
  
  witchkillending: {
    setVars: { hasLooped: 0 },
    title: "Here you go again",
    text: "You step up and lunge towards her, with only the adrenaline keeping your wounded body able to move. Before you can reach her you lose contact with the ground, as you get suddendly throw on the side, towards the same window you crashed through before. You still hear the skull cakcling as you fly outside. You are not sure you can endure the fall again.",
    choices: [
    {text: "Ending: What did you expect?", next: "start"}
    ]
  },
  
}
 

let currentScene = 'start';
let typingInProgress = false;
let skipTyping = false;


function showScene(sceneKey) {
  const scene = story[sceneKey];
  currentScene = sceneKey;

  // Apply variable changes if any
  if (scene.setVars) {
    for (const [key, value] of Object.entries(scene.setVars)) {
      gameState[key] = value;  // update the gameState object
    }
  }

  const wrapper = document.getElementById("fisheye-wrapper");
  wrapper.classList.add("glitch");
  setTimeout(() => wrapper.classList.remove("glitch"), 300);

  document.getElementById("title").textContent = scene.title;

  const imageElement = document.getElementById("scene-image");
  if (scene.image) {
    imageElement.src = scene.image;
    imageElement.style.display = "block";
  } else {
    imageElement.style.display = "none";
    imageElement.src = "";
  }

  const textElement = document.getElementById("text");
  textElement.innerHTML = "";
  const choicesDiv = document.getElementById("choices");
  choicesDiv.innerHTML = "";

  typingInProgress = true;
  skipTyping = false;

  typeText(scene.text, () => {
    typingInProgress = false;

    const sceneChoices = typeof scene.choices === "function" ? scene.choices() : (scene.choices || []);
    sceneChoices.forEach(choice => {
      const btn = document.createElement("button");
      btn.textContent = choice.text;
      btn.className = "choice";
      btn.onclick = () => {
        if (choice.effect) choice.effect();
        showScene(choice.next);
      };
      choicesDiv.appendChild(btn);
    });
  });
  
    // Update inventory display
  updateInventory();
    //gem=loop
 gameState.hasGem = gameState.hasLooped;

}


function typeText(text, callback) {
  const textElement = document.getElementById("text");
  textElement.innerHTML = "";
  let i = 0;
  const speed = 20;

  function glitchChar(char) {
    const chars = "!@#$%^&*()_+{}|<>?/[]~";
    return Math.random() < 0.3 ? chars[Math.floor(Math.random() * chars.length)] : char;
  }

  function typeNext() {
    if (skipTyping) {
      textElement.textContent = text;
      callback();
      return;
    }

    if (i < text.length) {
      const remaining = text.slice(i).toLowerCase();

      if (remaining.startsWith("witch")) {
        const letters = text.slice(i, i + 5).split("");

        letters.forEach((letter, index) => {
          const span = document.createElement("span");
          span.className = "witch-letter";
          span.textContent = glitchChar(letter);
          textElement.appendChild(span);

          setTimeout(() => {
            span.textContent = letter;
          }, 100 + Math.random() * 200);
        });

        i += 5;
        setTimeout(typeNext, speed);
        return;
      }

      // Normal character
      const realChar = text[i];
      const span = document.createElement("span");
      span.textContent = glitchChar(realChar);
      span.className = "glitch-text";
      textElement.appendChild(span);

      setTimeout(() => {
        span.textContent = realChar;
      }, 100 + Math.random() * 200);

      i++;
      setTimeout(typeNext, speed);
    } else {
      callback();
    }
  }
  
  const typingSound = new Audio("type.mp3"); // or a hosted URL
typingSound.volume = 0.2; // adjust volume as needed


  typeNext();
}


function updateInventory() {
  const popup = document.getElementById("inventory-popup");
  
  // Example: display items based on variables
  const items = [];

  if (gameState.hasVial) items.push("The Vial");
    if (gameState.hasBook) items.push("A Weird Book");
  if (gameState.hasGem) items.push("A small bright star");
  
  popup.textContent = items.length ? items.join("\n") : "Empty";
}

window.onload = () => {
  showScene(currentScene);
};

document.addEventListener("keydown", (e) => {
  if (typingInProgress && e.key === " ") {
    skipTyping = true;
  }
});

document.addEventListener("DOMContentLoaded", () => {
  document.body.style.userSelect = "none";
});

document.addEventListener("keydown", () => {
  if (typingInProgress) {
    skipTyping = true;
  }
});

document.addEventListener("click", () => {
  if (typingInProgress) {
    skipTyping = true;
  }
});

